// Q2)How did the structuring pass you performed, specifically the reversals chosen, affect swaps and comparisons? Was anything else affected? Answer in less than 100 words.
//
// There were less swaps/comparisons performed in total because sorting the elements into a decreasing order helps prevent
// redundent swaps and comparisons. 
// Q3)How do you feel the size of the specific runs you recorded (DESCENDING order of length 4) impacted performance? Answer in less than 100 words.
// With more numbers in a decreasing order, there were less comparisions made and less swapping needed because i knew with more certainty the location of each number.
//Q4)What would implementing this as a Doubly Linked List do? How would the specified structuring affect results? Answer in less than 100 words.
// Implementing it with the specific structure would simplify the code because all swaps can be done with the "Back" and "Next" variable of each Node.Altough im sure that the time complexity would stay the same (On^2). 
package comp352.assignment2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;




public class StructSort
{
    public static void main(String[] args) throws Exception {
        String fileName  = args[0];
        List<Integer> numbers = new ArrayList<>();
       
        // put numbers into arrayList
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] words = line.split(" ");

                for (String word : words) {
                    try {
                        int number = Integer.parseInt(word);
                        numbers.add(number);
                        
                    } catch (NumberFormatException e) {
                    }
                }
                
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        int Arrsize = numbers.size();
        for (int ind = 0;ind<Arrsize; ind++)
        {
            System.out.print(numbers.get(ind) + " ");                    
        }
        System.out.println("");  


        // implementing structural pass
        List<List<Integer>> number= changeAscending(numbers);

        numbers = number.get(0);
        
        // number of swaps
        int InitialSwap = number.get(1).get(0);
        int compared = number.get(2).get(0);
        number =insertion_sort(numbers);

        numbers = number.get(0); 
        InitialSwap += number.get(1).get(0); 
        compared += number.get(2).get(0);
        System.out.println("We performed " + compared+ " compares overall");
        System.out.println("We performed " + InitialSwap+ " swaps overall");
        for(int el :numbers )
        {
            System.out.print(el + " ");
        }
    }

        public static List<List<Integer>> changeAscending(List<Integer> numbers) {
            int flipnum = 0;
            List<Integer> sequence = new ArrayList<>();
            List<Integer> NoneInt = new ArrayList<>();
            List<Integer> Descenders = new ArrayList<>();
            boolean startedSeq = false;
            int counter = 0;
            int swapNo=0;
            int Dec=0;
            // Adding ASC to ascending list and DEC to descending list
            for(int i = 0;i<numbers.size()-1;)
            {
                if(numbers.get(i)<numbers.get(i+1))
                {
                    
                    startedSeq=true;
                    if (counter == 0)
                    {
                        flipnum++;
                        counter++;
                        sequence.add(numbers.get(i));
                        sequence.add(numbers.get(i+1));
                        
                        i++;  
                    }
                    else
                    {
                        sequence.add(numbers.get(i+1));
                        i++;
                    }
                    
                    
                }
                // switching the order from ASC to DEC
                else if (  startedSeq==true)
                {
                    // switch to descending using Collections in java.utils
                    
                    int start = 0;
                    int end = sequence.size() - 1;
                    while (start < end) {
                        int temp = sequence.get(start);
                        sequence.set(start, sequence.get(end));
                        sequence.set(end, temp);
                        swapNo++;
                        start++;
                        end--;
                    }
                    
                    NoneInt.addAll(sequence);
                    sequence.clear();
                    counter=0;
                    startedSeq=false;
                    i++; 
                }
                else
                {
                    // Check for descending order
                    
                    if(4+i<numbers.size())
                    {
                        for(int k=0;k<4;k++)
                        {
                            Descenders.add(numbers.get(i+k));
                        }
                        
                        if 
                        (
                            Descenders.get(0) > Descenders.get(1) &&
                            Descenders.get(1) > Descenders.get(2) &&
                            Descenders.get(2) > Descenders.get(3)) {
                            Dec+=1;
                            Descenders.clear();
                                
                        }
                            
                        
                        
                    }
                    NoneInt.add(numbers.get(i));
                    NoneInt.add(numbers.get(i+1));
                    startedSeq=false;
                    i+=2;
                }
            }

            // swapping order
            int start = 0;
            int end = sequence.size() - 1;
            while (start < end) {
                int temp = sequence.get(start);
                sequence.set(start, sequence.get(end));
                sequence.set(end, temp);
                swapNo++;
                start++;
                end--;
            }
            
            NoneInt.addAll(sequence);
            sequence.clear();
            int compares = numbers.size()-1;
            // we have to return both the swap amount and total amount
            List<List<Integer>> total = new ArrayList<>();
            List<Integer> swapno = new ArrayList<>();
            List<Integer> Compared = new ArrayList<>();
            swapno.add(swapNo);
            total.add(NoneInt);
            total.add(swapno);

            Compared.add(compares);
            total.add(Compared);
            System.out.println("We sorted in ASC order");
            System.out.println("We counted "+ Dec+ " DEC runs of length 4");
            System.out.println("We performed " + flipnum + " reversals of runs in ASC order");
           System.out.println("We performed " + compares + " compares during structuring");
            return total;

            

        }

        public static List<List<Integer>> insertion_sort ( List<Integer> A ) {
            int size = A.size();
            int SwapNo=0;
            int Comps=0;
            List<Integer> Swaps = new ArrayList<>();
            List<Integer> Comparisons = new ArrayList<>();
            List<List<Integer>> end = new ArrayList<>();
            for (int i = 1; i < size; i++) 
            {
                int b = A.get(i);
                int j = i - 1;
                Comps++;
                while (j >= 0 && A.get(j) > b) {
                    Comps++;
                    SwapNo++;
                    A.set(j + 1, A.get(j));
                    j--;
                }

                A.set(j + 1, b);
            }   

            Swaps.add(SwapNo);
            Comparisons.add(Comps-2);
            end.add(A);
            end.add(Swaps);
            end.add(Comparisons);
            
            return end;
    }
        
}
